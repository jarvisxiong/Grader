package token.command;

import util.annotations.Tags;

@Tags({ "define" })
public interface IDefineCommandToken extends ICommandToken {

}
