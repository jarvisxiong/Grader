package token.command;

import util.annotations.Tags;

@Tags({ "redo" })
public interface IRedoCommandToken extends ICommandToken {

}
