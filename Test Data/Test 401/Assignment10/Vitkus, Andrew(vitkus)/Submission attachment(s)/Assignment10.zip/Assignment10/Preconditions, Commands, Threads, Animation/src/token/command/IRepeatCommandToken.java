package token.command;

import util.annotations.Tags;

@Tags({ "repeat" })
public interface IRepeatCommandToken extends ICommandToken {

}
