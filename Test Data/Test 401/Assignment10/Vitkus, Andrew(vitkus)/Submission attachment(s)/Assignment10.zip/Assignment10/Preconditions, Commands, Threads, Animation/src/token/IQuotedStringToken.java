package token;

import util.annotations.Tags;

@Tags({ "Quote Token" })
public interface IQuotedStringToken extends IToken {

}
