package token.command;

import util.annotations.Tags;

@Tags({ "say" })
public interface ISayCommandToken extends ICommandToken {

}
