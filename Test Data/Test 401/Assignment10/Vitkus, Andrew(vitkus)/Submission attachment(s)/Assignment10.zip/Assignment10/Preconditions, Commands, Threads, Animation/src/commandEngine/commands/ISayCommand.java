package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Say Command" })
public interface ISayCommand extends ICommand {

}
