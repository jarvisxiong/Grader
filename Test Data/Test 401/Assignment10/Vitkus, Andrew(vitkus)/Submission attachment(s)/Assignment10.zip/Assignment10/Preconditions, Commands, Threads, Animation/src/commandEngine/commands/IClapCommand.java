package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Clap Command" })
public interface IClapCommand extends ICommand {

}
