package graphics.animation;

import util.annotations.Tags;

@Tags({ "animating command" })
public interface IClapAnimatingCommand extends IAnimatingCommand {

}
