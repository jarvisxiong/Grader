package token.command;

import util.annotations.Tags;

@Tags({ "proceedAll" })
public interface IProceedAllCommandToken extends ICommandToken {

}
