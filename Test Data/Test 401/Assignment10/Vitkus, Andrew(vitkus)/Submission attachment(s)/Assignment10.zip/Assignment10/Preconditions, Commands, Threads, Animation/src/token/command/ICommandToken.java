package token.command;

import token.IWordToken;
import util.annotations.Tags;

@Tags({ "Command Token" })
public interface ICommandToken extends IWordToken {

}
