package commandEngine.tokenizer;

public enum TokenType {
	NUMBER, WORD, QUOTED_STRING
};
