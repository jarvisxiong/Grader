package token;

import util.annotations.Tags;

@Tags({ "Plus Token" })
public interface IPlusToken extends IToken {

}
