package token;

import util.annotations.Tags;

@Tags({ "Minus Token" })
public interface IMinusToken extends IToken {

}
