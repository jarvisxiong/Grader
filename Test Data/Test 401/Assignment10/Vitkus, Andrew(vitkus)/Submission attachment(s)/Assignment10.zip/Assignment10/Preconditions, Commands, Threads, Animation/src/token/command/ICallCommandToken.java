package token.command;

import util.annotations.Tags;

@Tags({ "call" })
public interface ICallCommandToken extends ICommandToken {

}
