package token.command;

import util.annotations.Tags;

@Tags({ "approach" })
public interface IApproachCommandToken extends ICommandToken {

}
