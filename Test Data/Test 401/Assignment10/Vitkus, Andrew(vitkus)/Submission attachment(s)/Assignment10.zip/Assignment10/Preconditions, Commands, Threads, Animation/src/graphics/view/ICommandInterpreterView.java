package graphics.view;

import java.beans.PropertyChangeListener;

public interface ICommandInterpreterView extends PropertyChangeListener, Runnable  {
}
