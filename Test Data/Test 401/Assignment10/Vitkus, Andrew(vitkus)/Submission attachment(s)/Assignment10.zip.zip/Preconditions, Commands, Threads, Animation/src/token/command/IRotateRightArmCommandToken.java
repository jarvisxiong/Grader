package token.command;

import util.annotations.Tags;

@Tags({ "rotateRightArm" })
public interface IRotateRightArmCommandToken extends ICommandToken {

}
