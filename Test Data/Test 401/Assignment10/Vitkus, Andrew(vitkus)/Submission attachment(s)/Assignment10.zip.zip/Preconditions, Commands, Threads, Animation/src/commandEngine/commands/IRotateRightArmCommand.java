package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Rotate Right Arm Command" })
public interface IRotateRightArmCommand extends ICommand {

}
