package token.command;

import util.annotations.Tags;

@Tags({ "move" })
public interface IMoveCommandToken extends ICommandToken {

}
