package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Approach Command" })
public interface IApproachCommand extends ICommand {

}
