package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Pass Command" })
public interface IPassCommand extends ICommand {

}
