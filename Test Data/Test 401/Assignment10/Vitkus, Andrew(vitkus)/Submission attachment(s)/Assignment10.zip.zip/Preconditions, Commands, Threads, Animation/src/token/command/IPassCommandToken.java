package token.command;

import util.annotations.Tags;

@Tags({ "pass" })
public interface IPassCommandToken extends ICommandToken {

}
