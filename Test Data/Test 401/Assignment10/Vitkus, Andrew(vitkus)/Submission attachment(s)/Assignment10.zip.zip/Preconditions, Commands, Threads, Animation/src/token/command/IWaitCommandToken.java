package token.command;

import util.annotations.Tags;

@Tags({ "wait" })
public interface IWaitCommandToken extends ICommandToken {

}
