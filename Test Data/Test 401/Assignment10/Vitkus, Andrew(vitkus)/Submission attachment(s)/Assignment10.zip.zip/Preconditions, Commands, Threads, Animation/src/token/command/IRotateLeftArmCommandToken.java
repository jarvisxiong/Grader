package token.command;

import util.annotations.Tags;

@Tags({ "rotateLeftArm" })
public interface IRotateLeftArmCommandToken extends ICommandToken {

}
