package graphics.view;

import java.beans.PropertyChangeListener;

import util.annotations.Tags;

@Tags( { "Console Scene View" } )
public interface IConsoleSceneView extends PropertyChangeListener {

}
