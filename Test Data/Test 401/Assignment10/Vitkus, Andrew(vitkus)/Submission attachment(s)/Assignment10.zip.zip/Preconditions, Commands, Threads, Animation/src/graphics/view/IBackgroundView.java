package graphics.view;

import util.PaintListener;

public interface IBackgroundView extends PaintListener {

}
