package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Move Command" })
public interface IMoveCommand extends ICommand {

}
