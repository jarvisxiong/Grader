package token.command;

import util.annotations.Tags;

@Tags({ "thread" })
public interface IThreadCommandToken extends ICommandToken {

}
