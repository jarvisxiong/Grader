package token.command;

import util.annotations.Tags;

@Tags({ "undo" })
public interface IUndoCommandToken extends ICommandToken {

}
