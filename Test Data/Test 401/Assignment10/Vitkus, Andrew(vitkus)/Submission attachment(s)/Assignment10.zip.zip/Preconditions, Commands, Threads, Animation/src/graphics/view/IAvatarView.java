package graphics.view;

import java.beans.PropertyChangeListener;

import util.PaintListener;

public interface IAvatarView extends PaintListener, PropertyChangeListener {

}
