package token;

import util.annotations.Tags;

@Tags({ "Start Token" })
public interface IStartToken extends IToken {

}
