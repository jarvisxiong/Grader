package graphics.types;

public interface IBoundedMovableShape extends IBoundedShape, IMovable {

}
