package token;

import util.annotations.Tags;

@Tags({ "End Token" })
public interface IEndToken extends IToken {

}
