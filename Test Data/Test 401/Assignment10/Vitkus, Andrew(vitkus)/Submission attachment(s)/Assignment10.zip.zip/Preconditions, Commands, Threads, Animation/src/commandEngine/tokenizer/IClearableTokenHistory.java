package commandEngine.tokenizer;

public interface IClearableTokenHistory extends ITokenHistory {
	public void clear();
}
