package token.command;

import util.annotations.Tags;

@Tags({ "fail" })
public interface IFailCommandToken extends ICommandToken {

}
