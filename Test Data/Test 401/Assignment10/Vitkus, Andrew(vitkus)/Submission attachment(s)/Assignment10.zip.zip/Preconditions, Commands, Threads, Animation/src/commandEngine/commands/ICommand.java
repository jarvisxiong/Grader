package commandEngine.commands;

public interface ICommand extends Runnable {

}
