package graphics.animation;

import util.annotations.Tags;

@Tags({ "animating command" })
public interface IAnimatingCommand extends Runnable {

}
