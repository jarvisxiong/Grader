package graphics.types;

public interface IMovableResizableShape extends IMovable, IResizableShape {

}
