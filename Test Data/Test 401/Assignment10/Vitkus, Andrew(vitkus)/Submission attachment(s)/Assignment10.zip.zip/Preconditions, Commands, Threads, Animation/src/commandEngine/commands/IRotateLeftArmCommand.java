package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Rotate Left Arm Command" })
public interface IRotateLeftArmCommand extends ICommand {

}
