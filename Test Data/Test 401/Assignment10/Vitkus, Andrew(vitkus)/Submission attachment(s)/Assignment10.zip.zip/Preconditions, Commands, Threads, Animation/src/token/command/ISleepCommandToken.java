package token.command;

import util.annotations.Tags;

@Tags({ "sleep" })
public interface ISleepCommandToken extends ICommandToken {

}
