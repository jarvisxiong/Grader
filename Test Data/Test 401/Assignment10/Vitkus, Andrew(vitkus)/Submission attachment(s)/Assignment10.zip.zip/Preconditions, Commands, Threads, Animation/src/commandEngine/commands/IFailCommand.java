package commandEngine.commands;

import util.annotations.Tags;

@Tags({ "Fail Command" })
public interface IFailCommand extends ICommand {

}
