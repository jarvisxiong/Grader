package examples.rmi.arithmetic.stateful;

public interface MixedTypeAirthmeticServer {
	public static final String SERVER_NAME = "Remote Mixed Type Arithmetic";
}
