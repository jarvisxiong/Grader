package editor.ot;

public interface OperationTransformerCreator {
	public OperationTransformer getOperationTransformer();
}
