package im.access;

public interface Message<DataType> {
	public DataType getData();
}
