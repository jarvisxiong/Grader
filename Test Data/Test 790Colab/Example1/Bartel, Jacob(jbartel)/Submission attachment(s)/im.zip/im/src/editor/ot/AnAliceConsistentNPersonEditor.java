package editor.ot;
// need to start OTSessionManagerServer
public class AnAliceConsistentNPersonEditor {
	public static void main (String[] args) {
		args = new String[] {"localhost", "testsession", "alice"};
		AConsisentNPersonEditor.main(args);
	}

}
