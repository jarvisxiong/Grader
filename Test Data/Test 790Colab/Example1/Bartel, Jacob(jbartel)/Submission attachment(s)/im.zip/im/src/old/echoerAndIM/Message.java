package old.echoerAndIM;
public interface Message<DataType> {
	public DataType getData();
}
