package clean.centralizedWindow;

import java.util.List;

import util.awt.OutputListener;

public interface OutputLoggerAndListener extends OutputListener{
	public List getOutputLog();

}
