package im.ot;

public interface OperationTransformerCreator {
	public OperationTransformer getOperationTransformer();
}
