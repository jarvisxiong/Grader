package old.echoerAndIM;
//import util.multicast.Multicaster;
public interface InputCommunicatorAndLogger extends Echoer {
	//public MulticastClient getMulticastClient();
}