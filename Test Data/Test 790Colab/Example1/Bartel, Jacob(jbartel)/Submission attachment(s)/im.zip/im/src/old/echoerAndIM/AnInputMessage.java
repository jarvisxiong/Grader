package old.echoerAndIM;
public class AnInputMessage extends AMessage<String> {
	public AnInputMessage (String theInput) {
		super(theInput);
	}
}
