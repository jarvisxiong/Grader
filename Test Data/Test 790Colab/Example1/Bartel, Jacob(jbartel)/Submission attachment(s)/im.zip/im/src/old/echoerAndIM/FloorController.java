package old.echoerAndIM;

public interface FloorController extends Vetoer{
	public void newFloorHolder(String newVal);
	public boolean hasFloor();
	public void getFloor();
}