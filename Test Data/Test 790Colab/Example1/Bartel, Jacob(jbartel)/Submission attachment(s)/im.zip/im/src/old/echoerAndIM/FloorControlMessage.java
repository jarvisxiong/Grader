package old.echoerAndIM;
public interface FloorControlMessage {
	public String getClientName();
}
