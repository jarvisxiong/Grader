package old.echoerAndIM;
public class AReleaseFloorMessage extends AMessage<String> {
	public AReleaseFloorMessage (String theClientName) {
		super(theClientName);
	}
}
