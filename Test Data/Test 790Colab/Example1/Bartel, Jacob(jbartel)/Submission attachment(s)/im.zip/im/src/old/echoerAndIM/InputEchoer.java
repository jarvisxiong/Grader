package old.echoerAndIM;
public interface InputEchoer {
	public void doInput();
}