package editor.ot;
// need to start OTSessionManagerServer
public class ACathyConsistentNPersonEditor {
	public static void main (String[] args) {
		args = new String[] {"localhost", "testsession", "cathy"};
		AConsisentNPersonEditor.main(args);
	}

}
