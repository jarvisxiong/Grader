package old.echoerAndIM;
public interface Echoer {
	public void doInput();
	public void addToHistory(String input);
	public void printHistory();
}