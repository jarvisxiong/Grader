package old.replicatedWindow;

public class AliceReplicatedWindow {
	public static void main (String[] args) {
		ReplicatedCharacterDrawer.main(new String[] {"localhost", "repwindow", "alice"});
	}

}
