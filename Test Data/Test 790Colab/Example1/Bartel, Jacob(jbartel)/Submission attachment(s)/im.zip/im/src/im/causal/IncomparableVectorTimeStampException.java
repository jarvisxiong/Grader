package im.causal;

public class IncomparableVectorTimeStampException  extends RuntimeException{
	public IncomparableVectorTimeStampException(String message) {
		super(message);
	}

}
