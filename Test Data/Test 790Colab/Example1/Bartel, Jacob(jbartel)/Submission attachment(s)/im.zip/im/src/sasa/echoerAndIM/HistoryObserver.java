package sasa.echoerAndIM;

public interface HistoryObserver<ElementType> {
	void elementAdded(ElementType newValue);

}
