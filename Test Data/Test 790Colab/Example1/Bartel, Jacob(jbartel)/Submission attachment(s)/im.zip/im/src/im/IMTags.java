package im;

public interface IMTags {
	String IM = "IM";

}
