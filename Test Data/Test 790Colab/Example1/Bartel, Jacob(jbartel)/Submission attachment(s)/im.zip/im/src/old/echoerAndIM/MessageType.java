package old.echoerAndIM;

public enum MessageType {
	INPUT,
	GET_FLOOR,
	RELEASE_FLOOR,
	ACCESS_CONTROL
}
