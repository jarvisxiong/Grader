package widgets;

public interface TextFieldListener {
	void elementInserted (int index, char ch);
}
