package replicatedWindow;

public interface ExampleSharedWindowsSession {
	public static final String SESSION_NAME = "Shared Windows Session";
	public static final String APPLICATION_NAME = "Random Widgets";
	public static final String SESSION_SERVER_HOST = "localhost";

}
