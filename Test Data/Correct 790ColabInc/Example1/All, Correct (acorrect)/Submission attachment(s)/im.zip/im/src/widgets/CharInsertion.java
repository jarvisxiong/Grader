package widgets;


public interface CharInsertion extends Edit {

	
}