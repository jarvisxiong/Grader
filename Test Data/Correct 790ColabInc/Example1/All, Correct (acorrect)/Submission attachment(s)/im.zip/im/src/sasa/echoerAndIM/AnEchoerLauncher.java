package sasa.echoerAndIM;

public class AnEchoerLauncher {
	public static void main (String[] args) {
		Echoer echoer = new AnEchoer();
		echoer.doInput();
	}
}
