package old.echoerAndIM;
public class AGetFloorMessage extends AMessage<String> {
	public AGetFloorMessage (String theClientName) {
		//super(MessageType.GET_FLOOR, theClientName);
		super(theClientName);
	}
}
