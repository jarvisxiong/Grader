package sasa.echoerAndIM;

public interface Message<DataType> {
	public DataType getData();
}
