package old.echoerAndIM;
public class ARemoteInput extends AMessage<String> {
	public ARemoteInput (String theUserName) {
		super(theUserName);
	}
}
