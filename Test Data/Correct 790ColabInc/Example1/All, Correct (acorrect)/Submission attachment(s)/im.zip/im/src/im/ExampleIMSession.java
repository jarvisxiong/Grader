package im;

public interface ExampleIMSession {
	public static final String SESSION_NAME = "FrostySession";
	public static final String APPLICATION_NAME = "IM";
	public static final String SESSION_SERVER_HOST = "localhost";

}
