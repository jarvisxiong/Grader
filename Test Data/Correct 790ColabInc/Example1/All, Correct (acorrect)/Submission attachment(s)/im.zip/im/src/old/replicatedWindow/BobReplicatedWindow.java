package old.replicatedWindow;

public class BobReplicatedWindow {
	public static void main (String[] args) {
		ReplicatedCharacterDrawer.main(new String[] {"localhost", "repwindow", "bob"});
	}

}
