package old.echoerAndIM;
//import util.multicast.Multicaster;
public interface InputCommunicator extends InputEchoer {
	//public MulticastClient getMulticastClient();
}