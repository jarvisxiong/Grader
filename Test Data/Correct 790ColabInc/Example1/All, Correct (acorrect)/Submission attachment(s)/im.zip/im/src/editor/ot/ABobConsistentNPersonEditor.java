package editor.ot;
// need to start OTSessionManagerServer
public class ABobConsistentNPersonEditor {
	public static void main (String[] args) {
		args = new String[] {"localhost", "testsession", "bob"};
		AConsisentNPersonEditor.main(args);
	}

}
