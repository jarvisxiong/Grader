package echo.monolithic;

public interface Tester {
	void test();

}
