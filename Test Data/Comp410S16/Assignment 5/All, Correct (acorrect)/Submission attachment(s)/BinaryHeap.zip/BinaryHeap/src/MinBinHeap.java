import java.util.*;

public class MinBinHeap implements HeapInterface {

    // in here go all your data and methods for the heap

    EntryPair[] array = new EntryPair[100];
    int size =0;
    public MinBinHeap ( ) { // default constructor

    }

    @Override
    public void insert(EntryPair entry) {
        int hole = ++size;
        for(array[0]=entry; entry.getPriority()<array[hole/2].getPriority(); hole /=2) {
            array[hole] = array[hole/2];
        }
        array[hole] = entry;
    }

    @Override
    public void delMin() {
        if(size==0) throw new NoSuchElementException();
        EntryPair min = getMin();
        array[1] = array[size--];
        percolateDown(1);
    }

    @Override
    public EntryPair getMin() {
        return array[1];
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void build(EntryPair[] entries) {
        array = new EntryPair[100];
        size =entries.length;
        int i=1;
        for(EntryPair item :entries) {
            array[i++]= item;
        }

        for(int j=size/2;j>0;j--) {
            print();
            percolateDown(j);
        }

    }
    private void percolateDown(int hole) {
        int child;
        EntryPair tmp = array[hole];
        for(;hole*2<=size; hole=child) {
            child=hole*2;
            if(child!=size && array[child+1].getPriority()<array[child].getPriority())
                child++;
            if(array[child].getPriority()<tmp.getPriority())
                array[hole]=array[child];
            else break;
        }
        array[hole] = tmp;
    }
    void print() {
       System.out.println(Arrays.toString(array));
    }
    public static void main(String[] args) {
        Integer[] load = {13,14,16,19,21,19,68,65,26,32,31};
        List<Integer> l = new ArrayList<>(Arrays.asList(load));
        Collections.shuffle(l);
        System.out.println(l);
//        int [] load = {150,80,40,30,10,70,110,100,20,90,60,50,120,140,130};
        MinBinHeap heap = new MinBinHeap();
        for(int i=0;i<11;i++) {
            heap.insert(new EntryPair("",load[i]));
//            heap.print();
        }
        heap.delMin();
        heap.insert(new EntryPair("",99));
//        EntryPair[] build = new EntryPair[15];
//        for (int i=0;i<15;i++)
//            build[i] = new EntryPair("",load[i]);
//        heap.build(build);
//        heap.print();

    }
}