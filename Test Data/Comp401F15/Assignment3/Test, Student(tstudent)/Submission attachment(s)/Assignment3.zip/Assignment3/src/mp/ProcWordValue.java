package mp;

public interface ProcWordValue {
	public String getValue();
}
