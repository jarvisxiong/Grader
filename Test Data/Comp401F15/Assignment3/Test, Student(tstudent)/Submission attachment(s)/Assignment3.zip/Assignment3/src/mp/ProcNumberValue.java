package mp;

public interface ProcNumberValue {
	public int getValue();
}
