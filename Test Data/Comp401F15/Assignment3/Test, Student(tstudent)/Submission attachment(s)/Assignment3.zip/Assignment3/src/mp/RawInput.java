package mp;

public interface RawInput {
	public void setInput(String input);
	public String getInput();
}
