package grail;

public interface ScannerInterface {
	public void setScannedString(String str);
	public String getScannedString();
	public void scanString(String line);
}
