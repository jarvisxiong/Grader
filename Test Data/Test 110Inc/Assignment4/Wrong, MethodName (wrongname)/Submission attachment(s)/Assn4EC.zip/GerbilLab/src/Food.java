
public class Food {

	String name;
	String color;
	int maxAmount;
	
	public void setName(String newName)
	{
		name = newName;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setColor(String newColor)
	{
		color = newColor;
	}
	
	public String getColor()
	{
		return color;
	}
	
	public void setAmount(int newAmount)
	{
		maxAmount = newAmount;
	}
	
	public int getAmount()
	{
		return maxAmount;
	}
}
