
public class HelloWorld {
	
	private void main(String args) {
		System.out.println("Hello World");
	}
}
